"""
ElevenLabs Service — Voice cloning and text-to-speech.
Clones a voice from an audio sample and generates speech in that voice.
"""

import os
import uuid
from elevenlabs.client import ElevenLabs
from elevenlabs import VoiceSettings
from config import ELEVENLABS_API_KEY, ELEVENLABS_MODEL, UPLOAD_DIR


client = ElevenLabs(api_key=ELEVENLABS_API_KEY)

# Store cloned voice IDs per session
cloned_voices: dict[str, str] = {}


async def clone_voice(session_id: str, audio_file_path: str, voice_name: str = None) -> str:
    """
    Clone a voice from an audio sample file.
    Returns the voice ID of the cloned voice.
    """
    if voice_name is None:
        voice_name = f"clone_{session_id[:8]}"

    with open(audio_file_path, "rb") as f:
        voice = client.voices.ivc.create(
            name=voice_name,
            files=[f],
            description=f"Cloned voice for session {session_id}",
        )

    voice_id = voice.voice_id
    cloned_voices[session_id] = voice_id
    print(f"✅ Voice cloned successfully! Voice ID: {voice_id}")
    return voice_id


async def generate_speech(session_id: str, text: str) -> str:
    """
    Generate speech audio from text using the cloned voice.
    Returns the path to the generated audio file.
    """
    voice_id = cloned_voices.get(session_id)
    if not voice_id:
        raise ValueError("No cloned voice found for this session. Please upload a voice sample first.")

    # Clean emotion tags from text before speaking
    import re
    clean_text = re.sub(r'\[\w+\]\s*', '', text)

    audio_generator = client.text_to_speech.convert(
        voice_id=voice_id,
        text=clean_text,
        model_id=ELEVENLABS_MODEL,
        voice_settings=VoiceSettings(
            stability=0.5,
            similarity_boost=0.8,
            style=0.6,
            use_speaker_boost=True,
        ),
    )

    # Save audio to file
    output_path = os.path.join(UPLOAD_DIR, f"speech_{uuid.uuid4().hex[:12]}.mp3")
    with open(output_path, "wb") as f:
        for chunk in audio_generator:
            f.write(chunk)

    print(f"🎤 Speech generated: {output_path}")
    return output_path


def get_voice_id(session_id: str) -> str | None:
    """Get the cloned voice ID for a session."""
    return cloned_voices.get(session_id)


async def delete_voice(session_id: str):
    """Delete the cloned voice from ElevenLabs."""
    voice_id = cloned_voices.get(session_id)
    if voice_id:
        try:
            client.voices.delete(voice_id)
            del cloned_voices[session_id]
            print(f"🗑️ Voice {voice_id} deleted")
        except Exception as e:
            print(f"⚠️ Failed to delete voice: {e}")
